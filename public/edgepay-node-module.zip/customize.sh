#!/system/bin/sh
# 刷入时执行一次。只做校验与目录准备，不碰系统分区。

SKIPUNZIP=0

ui_print " "
ui_print "- EdgePay 收款监听节点"
ui_print "  Android SDK: $API"

if [ "$API" -lt 26 ]; then
  abort "! 需要 Android 8.0 (API 26) 或更高版本"
fi

if [ ! -f /system/bin/app_process ] && [ ! -f /system/bin/app_process64 ]; then
  abort "! 找不到 app_process，无法运行节点"
fi

mkdir -p /data/adb/edgepay
chmod 700 /data/adb/edgepay

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh" 0 0 0755
set_perm "$MODPATH/uninstall.sh" 0 0 0755
set_perm "$MODPATH/edgepay-node" 0 0 0755

if [ -f /data/adb/edgepay/config.json ]; then
  ui_print "- 已保留原有配置"
else
  ui_print "- 尚未配置。KernelSU / APatch 用户点模块的 WebUI 填写；"
  ui_print "  Magisk 没有 WebUI，请装 EdgePay APP 在配置页填写。"
fi

ui_print "- 重启后生效"
ui_print " "
