#!/system/bin/sh
# EdgePay 收款监听节点 —— 开机启动与看门狗。
#
# 由 Magisk / KernelSU / APatch 在 late_start service 阶段执行。本脚本只负责"让守护进程一直
# 活着"，其余逻辑都在 edgepay-node.jar 里。

MODDIR=${0%/*}
DATADIR=/data/adb/edgepay
LOG="$DATADIR/service.log"

mkdir -p "$DATADIR"
chmod 700 "$DATADIR"

log() {
  echo "$(date '+%m-%d %H:%M:%S') $1" >>"$LOG"
  # 日志只留最近 400 行，避免长期运行把分区撑满。
  if [ "$(wc -l <"$LOG" 2>/dev/null || echo 0)" -gt 800 ]; then
    tail -n 400 "$LOG" >"$LOG.tmp" && mv "$LOG.tmp" "$LOG"
  fi
}

# 开机早期 /data 已挂载但系统服务尚未就绪，注册通知监听会直接失败。
# 等 sys.boot_completed 再启动，比起"失败后重试"少很多噪声。
wait_for_boot() {
  i=0
  while [ "$(getprop sys.boot_completed)" != "1" ] && [ "$i" -lt 300 ]; do
    sleep 2
    i=$((i + 1))
  done
}

is_disabled() {
  [ -f "$MODDIR/disable" ]
}

wait_for_boot
log "开机完成，准备启动节点"

# 看门狗：守护进程退出就重启。退避是必要的——配置缺失时进程会立刻退出，
# 不退避就会变成每秒重启一次的忙循环。
backoff=5
while true; do
  if is_disabled; then
    log "模块已被停用，看门狗退出"
    exit 0
  fi

  start_at=$(date +%s)
  CLASSPATH="$MODDIR/edgepay-node.jar" \
    app_process /system/bin cn.imsuk.edgepay.node.Main daemon
  exit_code=$?
  ran_for=$(($(date +%s) - start_at))

  if [ "$ran_for" -ge 60 ]; then
    # 正常跑了一段时间才退出，说明不是启动期配置问题，立刻重启。
    backoff=5
  else
    backoff=$((backoff * 2))
    [ "$backoff" -gt 300 ] && backoff=300
  fi
  log "节点退出(code=$exit_code, 运行 ${ran_for}s)，${backoff}s 后重启"
  sleep "$backoff"
done
