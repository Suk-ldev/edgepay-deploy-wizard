#!/system/bin/sh
# 卸载模块时执行。

# 1) 停掉守护进程。
PIDFILE=/data/adb/edgepay/node.pid
if [ -f "$PIDFILE" ]; then
  PID=$(cat "$PIDFILE" 2>/dev/null)
  [ -n "$PID" ] && kill "$PID" 2>/dev/null
fi
pkill -f cn.imsuk.edgepay.node.Main 2>/dev/null

# 2) 主动把监听交还给 APP。
#    模块在跑时 APP 是完全安静的（连常驻通知都收了），它要等看门狗任务下一次运行才会
#    发现模块没了——那最多要 15 分钟。这里直接拉起前台守护服务，交接是秒级的。
am start-foreground-service \
  -n cn.imsuk.edgepay.watcher/.WatcherKeepAliveService 2>/dev/null

# 3) 清掉包含密钥的运行目录。
#    卸载后不该在设备上留下明文密钥。配置需要保留的话，先在 WebUI 里导出备份。
rm -rf /data/adb/edgepay
